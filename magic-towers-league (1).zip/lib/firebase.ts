import { initializeApp, getApps, type FirebaseApp } from "firebase/app"
import { getAuth, type Auth } from "firebase/auth"
import { getAnalytics, type Analytics, isSupported } from "firebase/analytics"

const firebaseConfig = {
  apiKey: "AIzaSyCSJOA1e4j22vDHVcBEkFtSl_tVqq1fkPQ",
  authDomain: "magictowersleague-anmeldung.firebaseapp.com",
  projectId: "magictowersleague-anmeldung",
  storageBucket: "magictowersleague-anmeldung.firebasestorage.app",
  messagingSenderId: "870977390109",
  appId: "1:870977390109:web:4ea5ead858df4761d7a8f4",
  measurementId: "G-YQPGTJQG05",
}

let firebaseApp: FirebaseApp | undefined
let firebaseAuth: Auth | undefined
let firebaseAnalytics: Analytics | undefined

export const initializeFirebase = (): FirebaseApp => {
  if (typeof window !== "undefined" && !firebaseApp) {
    if (!getApps().length) {
      firebaseApp = initializeApp(firebaseConfig)
      console.log("Firebase initialized successfully")
    } else {
      firebaseApp = getApps()[0]
    }
  }
  return firebaseApp as FirebaseApp
}

export const getFirebaseAuth = (): Auth => {
  if (!firebaseAuth) {
    const app = initializeFirebase()
    firebaseAuth = getAuth(app)
  }
  return firebaseAuth
}

export const getFirebaseAnalytics = async (): Promise<Analytics | undefined> => {
  if (typeof window !== "undefined" && !firebaseAnalytics) {
    const app = initializeFirebase()
    if (await isSupported()) {
      firebaseAnalytics = getAnalytics(app)
    }
  }
  return firebaseAnalytics
}

