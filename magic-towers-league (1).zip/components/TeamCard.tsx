"use client"

import { useRef, useState } from "react"
import { useFrame } from "@react-three/fiber"
import { Text, useTexture } from "@react-three/drei"
import * as THREE from "three"

interface TeamCardProps {
  team: {
    name: string
    logo: string
    position: number
    points: number
    color: string
  }
}

export function TeamCard({ team }: TeamCardProps) {
  const meshRef = useRef<THREE.Mesh>(null!)
  const [hovered, setHovered] = useState(false)
  const [clicked, setClicked] = useState(false)

  // Load textures
  const texture = useTexture("/placeholder.svg")
  texture.encoding = THREE.sRGBEncoding

  useFrame((state, delta) => {
    if (hovered && !clicked) {
      meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, 0.5, 0.1)
    } else if (!clicked) {
      meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, 0, 0.1)
    }
  })

  return (
    <group
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      onClick={() => setClicked(!clicked)}
    >
      {/* Card Base */}
      <mesh ref={meshRef} position={[0, 0, 0]} castShadow receiveShadow>
        {/* Card Front */}
        <boxGeometry args={[1.5, 2, 0.1]} />
        <meshStandardMaterial color={team.color} metalness={0.5} roughness={0.3} />

        {/* Team Name */}
        <Text
          position={[0, -0.7, 0.06]}
          fontSize={0.12}
          color="white"
          anchorX="center"
          anchorY="middle"
          font="/fonts/Geist-Bold.ttf"
        >
          {team.name}
        </Text>

        {/* Position & Points */}
        <Text
          position={[0, -0.9, 0.06]}
          fontSize={0.1}
          color="white"
          anchorX="center"
          anchorY="middle"
          font="/fonts/Geist-Regular.ttf"
        >
          {`#${team.position} - ${team.points} Pts`}
        </Text>
      </mesh>

      {/* Team Logo */}
      <mesh position={[0, 0.3, 0.06]} scale={[0.8, 0.8, 0.1]}>
        <planeGeometry />
        <meshBasicMaterial map={texture} transparent opacity={0.9} />
      </mesh>
    </group>
  )
}

