"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { format } from "date-fns"
import { de } from "date-fns/locale"

const matches = [
  {
    id: 1,
    date: new Date("2024-02-25T19:30:00"),
    homeTeam: {
      name: "Phoenix Gaming",
      logo: "/placeholder.svg?height=64&width=64",
      score: null,
    },
    awayTeam: {
      name: "Dragon Warriors",
      logo: "/placeholder.svg?height=64&width=64",
      score: null,
    },
    venue: "Gaming Arena Stuttgart",
  },
  {
    id: 2,
    date: new Date("2024-02-26T18:00:00"),
    homeTeam: {
      name: "Neon Knights",
      logo: "/placeholder.svg?height=64&width=64",
      score: null,
    },
    awayTeam: {
      name: "Cyber Eagles",
      logo: "/placeholder.svg?height=64&width=64",
      score: null,
    },
    venue: "E-Sports Center München",
  },
  // Add more matches as needed
]

export function UpcomingMatches() {
  return (
    <section className="py-16 bg-gradient-to-b from-indigo-950/50 to-blue-900/50 backdrop-blur-lg">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
        >
          Kommende Matches
        </motion.h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {matches.map((match, index) => (
            <motion.div
              key={match.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-gradient-to-br from-indigo-900/50 to-blue-900/50 rounded-xl p-6 backdrop-blur-lg 
                         border border-blue-500/20 hover:border-blue-500/40 transition-all duration-300"
            >
              <div className="text-blue-300 text-sm mb-4">
                {format(match.date, "dd. MMMM yyyy, HH:mm 'Uhr'", { locale: de })}
              </div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="relative w-12 h-12">
                    <Image
                      src={match.homeTeam.logo || "/placeholder.svg"}
                      alt={match.homeTeam.name}
                      fill
                      className="object-contain"
                    />
                  </div>
                  <span className="font-semibold text-white">{match.homeTeam.name}</span>
                </div>
                <span className="text-2xl font-bold text-blue-400">VS</span>
                <div className="flex items-center space-x-3">
                  <span className="font-semibold text-white">{match.awayTeam.name}</span>
                  <div className="relative w-12 h-12">
                    <Image
                      src={match.awayTeam.logo || "/placeholder.svg"}
                      alt={match.awayTeam.name}
                      fill
                      className="object-contain"
                    />
                  </div>
                </div>
              </div>
              <div className="text-blue-300 text-sm text-center">{match.venue}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

