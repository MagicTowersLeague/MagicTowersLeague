"use client"

import Image from "next/image"
import { format } from "date-fns"
import { de } from "date-fns/locale"

const matches = [
  {
    date: new Date("2024-02-21T19:30:00"),
    homeTeam: { name: "Team Alpha", logo: "/placeholder.svg?height=24&width=24" },
    awayTeam: { name: "Team Beta", logo: "/placeholder.svg?height=24&width=24" },
  },
  {
    date: new Date("2024-02-22T14:30:00"),
    homeTeam: { name: "Team Gamma", logo: "/placeholder.svg?height=24&width=24" },
    awayTeam: { name: "Team Delta", logo: "/placeholder.svg?height=24&width=24" },
  },
  // Add more matches as needed
]

export function MatchSchedule() {
  return (
    <div className="bg-white border-b border-gray-200 overflow-x-auto">
      <div className="container mx-auto px-4">
        <div className="flex items-center h-20 space-x-8">
          {matches.map((match, index) => (
            <div key={index} className="flex items-center space-x-4 min-w-fit">
              <div className="text-sm text-gray-600">{format(match.date, "dd.MM. HH:mm", { locale: de })}</div>
              <div className="flex items-center space-x-2">
                <div className="relative w-6 h-6">
                  <Image
                    src={match.homeTeam.logo || "/placeholder.svg"}
                    alt={match.homeTeam.name}
                    fill
                    className="object-contain"
                  />
                </div>
                <span className="text-sm font-medium">vs</span>
                <div className="relative w-6 h-6">
                  <Image
                    src={match.awayTeam.logo || "/placeholder.svg"}
                    alt={match.awayTeam.name}
                    fill
                    className="object-contain"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

