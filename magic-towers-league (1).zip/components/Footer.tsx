import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-gradient-to-r from-primary to-black text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {[
            { title: "Magic Towers Liga", links: ["Über uns", "Kontakt", "Presse"] },
            { title: "Mehr", links: ["Fantasy Manager", "Mobile App", "Newsletter"] },
            { title: "Rechtliches", links: ["Impressum", "Datenschutz", "AGB"] },
          ].map((section, index) => (
            <div key={index}>
              <h3 className="text-xl font-semibold mb-4 glow-text">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link href="#" className="hover:text-accent transition-colors duration-200">
                      {link}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <div>
            <h3 className="text-xl font-semibold mb-4 glow-text">Folgen Sie uns</h3>
            <div className="flex space-x-4">{/* Add social media icons here */}</div>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-gray-700 text-center text-sm text-gray-400">
          © 2023 Magic Towers League. Alle Rechte vorbehalten.
        </div>
      </div>
    </footer>
  )
}

