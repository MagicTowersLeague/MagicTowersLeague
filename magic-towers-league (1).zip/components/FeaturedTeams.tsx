"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Trophy, Users, Star } from "lucide-react"

const teams = [
  {
    name: "Phoenix Gaming",
    logo: "/placeholder.svg?height=128&width=128",
    stats: {
      rank: 1,
      wins: 15,
      rating: 4.8,
    },
    members: ["Alex K.", "Sarah M.", "Mike R.", "Lisa T."],
    background: "/placeholder.svg?height=400&width=600",
  },
  {
    name: "Dragon Warriors",
    logo: "/placeholder.svg?height=128&width=128",
    stats: {
      rank: 2,
      wins: 13,
      rating: 4.6,
    },
    members: ["Tom B.", "Emma S.", "Chris L.", "Anna P."],
    background: "/placeholder.svg?height=400&width=600",
  },
  {
    name: "Neon Knights",
    logo: "/placeholder.svg?height=128&width=128",
    stats: {
      rank: 3,
      wins: 12,
      rating: 4.5,
    },
    members: ["Mark H.", "Julia R.", "David M.", "Nina S."],
    background: "/placeholder.svg?height=400&width=600",
  },
]

export function FeaturedTeams() {
  return (
    <section className="py-16 bg-gradient-to-b from-blue-900/50 to-indigo-950/50">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
        >
          Top Teams
        </motion.h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {teams.map((team, index) => (
            <motion.div
              key={team.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-indigo-950 rounded-xl"></div>
              <div className="relative bg-gradient-to-br from-indigo-900/50 to-blue-900/50 rounded-xl overflow-hidden">
                <Image
                  src={team.background || "/placeholder.svg"}
                  alt={team.name}
                  width={600}
                  height={400}
                  className="w-full h-48 object-cover opacity-50 group-hover:opacity-70 transition-opacity duration-300"
                />
                <div className="absolute top-4 left-4">
                  <div className="relative w-16 h-16">
                    <Image
                      src={team.logo || "/placeholder.svg"}
                      alt={`${team.name} logo`}
                      fill
                      className="object-contain"
                    />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-4">{team.name}</h3>
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="flex items-center space-x-2">
                      <Trophy className="w-4 h-4 text-yellow-400" />
                      <span className="text-blue-100">#{team.stats.rank}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Star className="w-4 h-4 text-yellow-400" />
                      <span className="text-blue-100">{team.stats.wins} Siege</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-blue-400" />
                      <span className="text-blue-100">{team.members.length}</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {team.members.map((member) => (
                      <span key={member} className="px-2 py-1 text-sm bg-blue-900/50 rounded-full text-blue-200">
                        {member}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

