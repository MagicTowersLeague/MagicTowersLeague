"use client"

import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

const navItems = [
  { label: "Home", href: "/" },
  { label: "Spielplan", href: "/spielplan" },
  { label: "Tabelle", href: "/tabelle" },
  { label: "Clubs", href: "/clubs" },
  { label: "Liveticker", href: "/liveticker" },
  { label: "History", href: "/history" },
  { label: "Videos", href: "/videos" },
  { label: "Tickets", href: "/tickets" },
  { label: "Statistiken", href: "/statistiken" },
  { label: "Awards", href: "/awards" },
  { label: "Spieler", href: "/spieler" },
  { label: "FAQ", href: "/faq" },
]

export function MainNav() {
  const pathname = usePathname()

  return (
    <div className="bg-white border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center">
            <Image
              src="/placeholder.svg?height=40&width=160"
              alt="Magic Towers League"
              width={160}
              height={40}
              className="h-10 w-auto"
            />
          </Link>
          <nav className="hidden lg:flex items-center space-x-6">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-blue-600",
                  pathname === item.href ? "text-blue-600" : "text-gray-600",
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </div>
  )
}

