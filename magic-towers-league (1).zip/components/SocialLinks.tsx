import { Twitter, Twitch, MessageCircle } from "lucide-react"

export function SocialLinks() {
  return (
    <div className="flex justify-center space-x-4">
      <a
        href="https://twitter.com"
        target="_blank"
        rel="noopener noreferrer"
        className="text-blue-300 hover:text-blue-100 transition-colors"
      >
        <Twitter className="w-6 h-6" />
      </a>
      <a
        href="https://twitch.tv"
        target="_blank"
        rel="noopener noreferrer"
        className="text-purple-300 hover:text-purple-100 transition-colors"
      >
        <Twitch className="w-6 h-6" />
      </a>
      <a
        href="https://discord.com"
        target="_blank"
        rel="noopener noreferrer"
        className="text-indigo-300 hover:text-indigo-100 transition-colors"
      >
        <MessageCircle className="w-6 h-6" />
      </a>
    </div>
  )
}

