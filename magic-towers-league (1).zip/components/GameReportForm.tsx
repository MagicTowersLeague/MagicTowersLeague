"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/components/AuthProvider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"

interface Player {
  name: string
  scores: number[]
}

interface Team {
  name: string
  county: string
  venue: string
  table: string
  captain: string
  players: Player[]
}

export function GameReportForm() {
  const { user, isTeamAdmin } = useAuth()
  const { toast } = useToast()
  const [date, setDate] = useState("")
  const [matchday, setMatchday] = useState("")
  const [homeTeam, setHomeTeam] = useState<Team>({
    name: "",
    county: "",
    venue: "",
    table: "",
    captain: "",
    players: Array(6).fill({ name: "", scores: Array(10).fill(0) }),
  })
  const [awayTeam, setAwayTeam] = useState<Team>({
    name: "",
    county: "",
    venue: "",
    table: "",
    captain: "",
    players: Array(6).fill({ name: "", scores: Array(10).fill(0) }),
  })
  const [notes, setNotes] = useState("")
  const [image, setImage] = useState<File | null>(null)

  const handlePlayerNameChange = (team: "home" | "away", index: number, name: string) => {
    const updatedTeam = team === "home" ? { ...homeTeam } : { ...awayTeam }
    updatedTeam.players[index].name = name
    team === "home" ? setHomeTeam(updatedTeam) : setAwayTeam(updatedTeam)
  }

  const handleScoreChange = (team: "home" | "away", playerIndex: number, gameIndex: number, score: number) => {
    const updatedTeam = team === "home" ? { ...homeTeam } : { ...awayTeam }
    updatedTeam.players[playerIndex].scores[gameIndex] = score
    team === "home" ? setHomeTeam(updatedTeam) : setAwayTeam(updatedTeam)
  }

  const calculateTotalScore = (players: Player[]) => {
    return players.reduce((total, player) => total + player.scores.reduce((sum, score) => sum + score, 0), 0)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !isTeamAdmin) {
      toast({
        title: "Zugriff verweigert",
        description: "Sie müssen als Team-Admin angemeldet sein, um einen Spielbericht abzugeben.",
        variant: "destructive",
      })
      return
    }

    // Here, implement the logic to save the report to Firestore
    // and upload the image to Firebase Storage
    // ...

    toast({
      title: "Spielbericht abgegeben",
      description: "Ihr Spielbericht wurde erfolgreich gespeichert.",
    })
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0])
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Magic Towers Liga - Spielberichtsbogen</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="date">Datum</Label>
              <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="matchday">Spieltag</Label>
              <Input id="matchday" value={matchday} onChange={(e) => setMatchday(e.target.value)} required />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Heimmannschaft Informationen */}
      <Card>
        <CardHeader>
          <CardTitle>Heimmannschaft</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="home-team">Mannschaftsname</Label>
              <Input
                id="home-team"
                value={homeTeam.name}
                onChange={(e) => setHomeTeam({ ...homeTeam, name: e.target.value })}
                required
              />
            </div>
            {/* Weitere Felder für Landkreis, Gastronomiebetrieb, etc. */}
          </div>
        </CardContent>
      </Card>

      {/* Gastmannschaft Informationen */}
      <Card>
        <CardHeader>
          <CardTitle>Gastmannschaft</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="away-team">Mannschaftsname</Label>
              <Input
                id="away-team"
                value={awayTeam.name}
                onChange={(e) => setAwayTeam({ ...awayTeam, name: e.target.value })}
                required
              />
            </div>
            {/* Weitere Felder für Landkreis, Gastronomiebetrieb, etc. */}
          </div>
        </CardContent>
      </Card>

      {/* Spielübersicht & Punktevergabe */}
      <Card>
        <CardHeader>
          <CardTitle>Spielübersicht & Punktevergabe</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Position</TableHead>
                <TableHead>Spielername</TableHead>
                {Array.from({ length: 10 }, (_, i) => (
                  <TableHead key={i}>{i + 1}. Spiel</TableHead>
                ))}
                <TableHead>Gesamtpunkte</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {homeTeam.players.map((player, index) => (
                <TableRow key={`home-${index}`}>
                  <TableCell>Heim {index + 1}</TableCell>
                  <TableCell>
                    <Input
                      value={player.name}
                      onChange={(e) => handlePlayerNameChange("home", index, e.target.value)}
                    />
                  </TableCell>
                  {player.scores.map((score, gameIndex) => (
                    <TableCell key={gameIndex}>
                      <Input
                        type="number"
                        value={score}
                        onChange={(e) => handleScoreChange("home", index, gameIndex, Number(e.target.value))}
                        min="0"
                        max="3"
                      />
                    </TableCell>
                  ))}
                  <TableCell>{player.scores.reduce((a, b) => a + b, 0)}</TableCell>
                </TableRow>
              ))}
              {awayTeam.players.map((player, index) => (
                <TableRow key={`away-${index}`}>
                  <TableCell>Gast {index + 1}</TableCell>
                  <TableCell>
                    <Input
                      value={player.name}
                      onChange={(e) => handlePlayerNameChange("away", index, e.target.value)}
                    />
                  </TableCell>
                  {player.scores.map((score, gameIndex) => (
                    <TableCell key={gameIndex}>
                      <Input
                        type="number"
                        value={score}
                        onChange={(e) => handleScoreChange("away", index, gameIndex, Number(e.target.value))}
                        min="0"
                        max="3"
                      />
                    </TableCell>
                  ))}
                  <TableCell>{player.scores.reduce((a, b) => a + b, 0)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Mannschaftsergebnis */}
      <Card>
        <CardHeader>
          <CardTitle>Mannschaftsergebnis</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Mannschaft</TableHead>
                <TableHead>Gesamtpunkte</TableHead>
                <TableHead>Ergebnis</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>{homeTeam.name}</TableCell>
                <TableCell>{calculateTotalScore(homeTeam.players)}</TableCell>
                <TableCell>
                  {calculateTotalScore(homeTeam.players) > calculateTotalScore(awayTeam.players)
                    ? "Sieg"
                    : calculateTotalScore(homeTeam.players) < calculateTotalScore(awayTeam.players)
                      ? "Niederlage"
                      : "Unentschieden"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>{awayTeam.name}</TableCell>
                <TableCell>{calculateTotalScore(awayTeam.players)}</TableCell>
                <TableCell>
                  {calculateTotalScore(awayTeam.players) > calculateTotalScore(homeTeam.players)
                    ? "Sieg"
                    : calculateTotalScore(awayTeam.players) < calculateTotalScore(homeTeam.players)
                      ? "Niederlage"
                      : "Unentschieden"}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Zusätzliche Anmerkungen */}
      <Card>
        <CardHeader>
          <CardTitle>Zusätzliche Anmerkungen</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Hier können Sie zusätzliche Anmerkungen eintragen..."
          />
        </CardContent>
      </Card>

      {/* Bild-Upload */}
      <Card>
        <CardHeader>
          <CardTitle>Bild hochladen</CardTitle>
        </CardHeader>
        <CardContent>
          <Input type="file" onChange={handleImageUpload} accept="image/*" />
        </CardContent>
      </Card>

      <Button type="submit" disabled={!isTeamAdmin}>
        {isTeamAdmin ? "Spielbericht abgeben" : "Nur für Team-Admins verfügbar"}
      </Button>
    </form>
  )
}

