"use client"

import * as React from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"

interface MatchResultDialogProps {
  isOpen: boolean
  onClose: () => void
  match: {
    id: number
    date: string
    homeTeam: string
    awayTeam: string
    homeScore: number | null
    awayScore: number | null
    homeTeamLogo?: string
    awayTeamLogo?: string
  }
  onSave: (matchId: number, homeScore: number, awayScore: number) => void
}

export function MatchResultDialog({ isOpen, onClose, match, onSave }: MatchResultDialogProps) {
  const [homeScore, setHomeScore] = React.useState<string>(match.homeScore?.toString() || "")
  const [awayScore, setAwayScore] = React.useState<string>(match.awayScore?.toString() || "")

  const handleSave = () => {
    const home = Number.parseInt(homeScore)
    const away = Number.parseInt(awayScore)
    if (!isNaN(home) && !isNaN(away)) {
      onSave(match.id, home, away)
      onClose()
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Spielergebnis eintragen</DialogTitle>
        </DialogHeader>
        <div className="space-y-6">
          <div className="text-center text-sm text-muted-foreground">{match.date}</div>
          <div className="grid grid-cols-[1fr,auto,1fr] gap-4 items-center">
            <div className="text-center space-y-2">
              <div className="relative w-16 h-16 mx-auto">
                <Image
                  src={match.homeTeamLogo || "/placeholder.svg?height=64&width=64"}
                  alt={match.homeTeam}
                  fill
                  className="object-contain"
                />
              </div>
              <div className="font-semibold">{match.homeTeam}</div>
              <Input
                type="number"
                min="0"
                value={homeScore}
                onChange={(e) => setHomeScore(e.target.value)}
                className="w-16 mx-auto text-center"
              />
            </div>
            <div className="text-2xl font-bold">:</div>
            <div className="text-center space-y-2">
              <div className="relative w-16 h-16 mx-auto">
                <Image
                  src={match.awayTeamLogo || "/placeholder.svg?height=64&width=64"}
                  alt={match.awayTeam}
                  fill
                  className="object-contain"
                />
              </div>
              <div className="font-semibold">{match.awayTeam}</div>
              <Input
                type="number"
                min="0"
                value={awayScore}
                onChange={(e) => setAwayScore(e.target.value)}
                className="w-16 mx-auto text-center"
              />
            </div>
          </div>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose}>
              Abbrechen
            </Button>
            <Button onClick={handleSave} className="bg-[#E4002B] text-white hover:bg-[#b30022]">
              Speichern
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

