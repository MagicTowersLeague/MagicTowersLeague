"use client"

import { useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Home, Info, Trophy, Calendar, Scroll, HelpCircle, Globe, UserPlus, LogIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { UserNav } from "@/components/UserNav"
import { useAuth } from "@/components/AuthProvider"
import { useSidebar } from "@/components/SidebarProvider"
import { LanguageSelector } from "@/components/LanguageSelector"
import { SocialLinks } from "@/components/SocialLinks"

const routes = [
  { label: "Home", icon: Home, href: "/" },
  { label: "Über uns", icon: Info, href: "/about" },
  { label: "Teams", icon: Trophy, href: "/teams" },
  { label: "Spielplan", icon: Calendar, href: "/spielplan" },
  { label: "Regelwerk", icon: Scroll, href: "/regelwerk" },
  { label: "FAQ", icon: HelpCircle, href: "/faq" },
  { label: "Team erstellen", icon: UserPlus, href: "/team-erstellen" },
]

export function Sidebar() {
  const pathname = usePathname()
  const { user } = useAuth()
  const { isOpen, toggleSidebar } = useSidebar()

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024 && isOpen) {
        toggleSidebar(false)
      }
    }
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [isOpen, toggleSidebar])

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden transition-opacity"
          onClick={() => toggleSidebar(false)}
        />
      )}

      <div
        className={cn(
          "fixed top-0 left-0 z-50 h-screen w-64 transform transition-transform duration-300 ease-in-out",
          "bg-gradient-to-b from-indigo-950 via-blue-900 to-indigo-950 text-white",
          isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
          "lg:relative lg:translate-x-0",
        )}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b border-indigo-800/50">
            <span className="text-lg font-semibold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Magic Towers League
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => toggleSidebar(false)}
              className="lg:hidden text-blue-100/80 hover:text-blue-100 hover:bg-white/5"
            >
              <Globe className="h-5 w-5" />
            </Button>
          </div>

          <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
            {routes.map((route) => (
              <Link
                key={route.href}
                href={route.href}
                className={cn(
                  "flex items-center px-3 py-2 text-sm rounded-lg transition-all duration-300",
                  "hover:bg-white/10 group relative overflow-hidden",
                  "hover:scale-105 hover:shadow-glow",
                  pathname === route.href
                    ? "text-blue-100 bg-gradient-to-r from-blue-500/20 to-purple-500/20"
                    : "text-blue-100/70 hover:text-blue-100",
                )}
              >
                <div
                  className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 
                              opacity-0 group-hover:opacity-100 transition-opacity"
                />
                <route.icon className="w-5 h-5 mr-3" />
                <span className="font-medium">{route.label}</span>
              </Link>
            ))}
          </nav>

          <div className="p-4 border-t border-indigo-800/50 space-y-4">
            <Button
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 
                       hover:from-blue-500 hover:to-purple-500 text-white border-0
                       transition-all duration-300 hover:scale-105 hover:shadow-glow"
            >
              Team anmelden
            </Button>
            {user ? (
              <UserNav />
            ) : (
              <Link href="/auth" passHref>
                <Button variant="ghost" className="w-full text-blue-100/80 hover:text-blue-100 hover:bg-white/5">
                  <LogIn className="w-5 h-5 mr-2" />
                  Anmelden / Registrieren
                </Button>
              </Link>
            )}
            <LanguageSelector />
            <SocialLinks />
          </div>
        </div>
      </div>
    </>
  )
}

