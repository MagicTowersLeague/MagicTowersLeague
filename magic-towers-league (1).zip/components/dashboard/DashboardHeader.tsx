import { Bell, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export function DashboardHeader() {
  return (
    <header className="h-16 border-b border-gray-800 bg-[#0F1117]/50 backdrop-blur-xl sticky top-0 z-40">
      <div className="h-full px-8 flex items-center justify-between">
        <div className="flex items-center flex-1">
          <div className="w-96">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search..."
                className="pl-10 bg-gray-900 border-gray-800 text-white placeholder:text-gray-500 focus-visible:ring-blue-500"
              />
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="relative text-gray-400 hover:text-white">
            <Bell className="h-5 w-5" />
            <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-blue-500" />
          </Button>
          <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-400 to-violet-400" />
        </div>
      </div>
    </header>
  )
}

