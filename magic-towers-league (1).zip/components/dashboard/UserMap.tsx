import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function UserMap() {
  return (
    <Card className="bg-[#1A1D24] border-gray-800">
      <CardHeader>
        <CardTitle className="text-white">Global Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] relative">
          {/* Replace with actual map implementation */}
          <div className="absolute inset-0 bg-[#1E2128] rounded-lg flex items-center justify-center">
            <p className="text-gray-400">Map visualization coming soon</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

