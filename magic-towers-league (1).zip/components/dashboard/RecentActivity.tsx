import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Trophy, User, Star, Target } from "lucide-react"

const activities = [
  {
    icon: Trophy,
    title: "Tournament Victory",
    description: "Team Alpha won the Summer Championship",
    time: "2 hours ago",
  },
  {
    icon: User,
    title: "New Player Joined",
    description: "Sarah Johnson joined the league",
    time: "4 hours ago",
  },
  {
    icon: Star,
    title: "Achievement Unlocked",
    description: "Team Beta reached 100 wins",
    time: "6 hours ago",
  },
  {
    icon: Target,
    title: "New Record",
    description: "Fastest match completion: 2m 30s",
    time: "12 hours ago",
  },
]

export function RecentActivity() {
  return (
    <Card className="bg-[#1A1D24] border-gray-800">
      <CardHeader>
        <CardTitle className="text-white">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div key={index} className="flex items-start space-x-4">
              <div className="p-2 rounded-full bg-gray-800">
                <activity.icon className="h-4 w-4 text-blue-400" />
              </div>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium text-white">{activity.title}</p>
                <p className="text-sm text-gray-400">{activity.description}</p>
                <p className="text-xs text-gray-500">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

