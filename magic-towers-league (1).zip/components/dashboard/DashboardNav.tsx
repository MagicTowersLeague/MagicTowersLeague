"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BarChart3, Users, Settings, HelpCircle, ChevronLeft, LayoutDashboard, Trophy, Calendar } from "lucide-react"

interface DashboardNavProps {
  collapsed: boolean
  setCollapsed: (collapsed: boolean) => void
}

export function DashboardNav({ collapsed, setCollapsed }: DashboardNavProps) {
  const pathname = usePathname()

  const routes = [
    {
      href: "/dashboard",
      icon: LayoutDashboard,
      title: "Dashboard",
    },
    {
      href: "/dashboard/tournaments",
      icon: Trophy,
      title: "Tournaments",
    },
    {
      href: "/dashboard/players",
      icon: Users,
      title: "Players",
    },
    {
      href: "/dashboard/schedule",
      icon: Calendar,
      title: "Schedule",
    },
    {
      href: "/dashboard/statistics",
      icon: BarChart3,
      title: "Statistics",
    },
    {
      href: "/dashboard/settings",
      icon: Settings,
      title: "Settings",
    },
  ]

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 h-screen bg-[#0F1117] border-r border-gray-800 transition-all duration-300",
        collapsed ? "w-20" : "w-64",
      )}
    >
      <div className="flex items-center justify-between h-16 px-4 border-b border-gray-800">
        <Link href="/dashboard" className={cn("flex items-center", collapsed ? "justify-center" : "")}>
          {!collapsed && (
            <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-violet-400 bg-clip-text text-transparent">
              Magic Towers
            </span>
          )}
        </Link>
        <button onClick={() => setCollapsed(!collapsed)} className="p-2 rounded-lg hover:bg-gray-800 transition-colors">
          <ChevronLeft className={cn("h-5 w-5 transition-transform", collapsed && "rotate-180")} />
        </button>
      </div>
      <div className="px-3 py-4">
        {routes.map((route) => (
          <Link
            key={route.href}
            href={route.href}
            className={cn(
              "flex items-center px-3 py-2 mb-1 rounded-lg transition-colors",
              pathname === route.href
                ? "bg-gradient-to-r from-blue-500/20 to-violet-500/20 text-white"
                : "text-gray-400 hover:text-white hover:bg-gray-800",
            )}
          >
            <route.icon className={cn("h-5 w-5", pathname === route.href && "text-blue-400")} />
            {!collapsed && <span className="ml-3">{route.title}</span>}
          </Link>
        ))}
      </div>
      <div className="absolute bottom-4 left-0 right-0 px-3">
        <Link
          href="/help"
          className={cn(
            "flex items-center px-3 py-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors",
            collapsed ? "justify-center" : "",
          )}
        >
          <HelpCircle className="h-5 w-5" />
          {!collapsed && <span className="ml-3">Help</span>}
        </Link>
      </div>
    </nav>
  )
}

