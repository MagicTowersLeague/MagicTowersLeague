import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import { Sphere } from "@react-three/drei"
import type * as THREE from "three"

export default function AnimatedSphere() {
  const meshRef = useRef<THREE.Mesh>(null!)

  useFrame((state, delta) => {
    meshRef.current.rotation.x += delta * 0.2
    meshRef.current.rotation.y += delta * 0.3
  })

  return (
    <Sphere args={[1, 32, 32]} ref={meshRef}>
      <meshStandardMaterial color="#1E90FF" wireframe />
    </Sphere>
  )
}

