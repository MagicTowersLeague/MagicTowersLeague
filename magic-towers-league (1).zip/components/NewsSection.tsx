"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Calendar, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const news = [
  {
    id: 1,
    title: "Großes Finale der Winterliga 2024",
    excerpt: "Die besten Teams treffen sich zum spannenden Showdown in Stuttgart.",
    image: "/placeholder.svg?height=400&width=600",
    date: "2024-02-25",
    category: "Turnier",
  },
  {
    id: 2,
    title: "Neue Saison startet im März",
    excerpt: "Alle Informationen zum Saisonstart und den Qualifikationsrunden.",
    image: "/placeholder.svg?height=400&width=600",
    date: "2024-02-20",
    category: "News",
  },
  {
    id: 3,
    title: "Team Phoenix mit Rekordsiegen",
    excerpt: "Die Erfolgsserie von Team Phoenix reißt nicht ab.",
    image: "/placeholder.svg?height=400&width=600",
    date: "2024-02-18",
    category: "Teams",
  },
]

export function NewsSection() {
  return (
    <section className="py-16 bg-gradient-to-b from-indigo-950/50 to-blue-900/50">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
        >
          Aktuelle News
        </motion.h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {news.map((item, index) => (
            <motion.article
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="relative h-48 mb-4 rounded-xl overflow-hidden">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-950/80 to-transparent"></div>
                <div className="absolute bottom-4 left-4 flex items-center space-x-2 text-sm">
                  <Calendar className="w-4 h-4 text-blue-400" />
                  <span className="text-blue-200">{item.date}</span>
                </div>
              </div>
              <span className="inline-block px-3 py-1 text-sm bg-blue-900/50 rounded-full text-blue-300 mb-3">
                {item.category}
              </span>
              <h3 className="text-xl font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">
                {item.title}
              </h3>
              <p className="text-blue-200 mb-4">{item.excerpt}</p>
              <Button variant="ghost" className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/50 p-0 h-auto">
                Weiterlesen <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}

