"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"

const cards = [
  {
    title: "Ace of Spades",
    image: "/placeholder.svg?height=400&width=300",
    description: "The highest card in the deck",
  },
  { title: "King of Hearts", image: "/placeholder.svg?height=400&width=300", description: "The suicide king" },
  { title: "Queen of Diamonds", image: "/placeholder.svg?height=400&width=300", description: "The queen of wealth" },
]

export function CardSection({ scrollY }: { scrollY: number }) {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [flippedCard, setFlippedCard] = useState<number | null>(null)

  useEffect(() => {
    const sectionTop = sectionRef.current?.offsetTop ?? 0
    const cards = sectionRef.current?.querySelectorAll(".card")

    cards?.forEach((card, index) => {
      const delay = index * 100
      const translateY = Math.max(0, Math.min(100, (scrollY - sectionTop + 400) / 2))
      ;(card as HTMLElement).style.transform = `translateY(${100 - translateY}px)`
      ;(card as HTMLElement).style.opacity = `${translateY / 100}`
    })
  }, [scrollY])

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-b from-primary to-black">
      <div className="container mx-auto px-4">
        <h2 className="text-5xl font-bold text-center mb-16 text-white glow-text">Featured Cards</h2>
        <div className="flex justify-center space-x-12">
          {cards.map((card, index) => (
            <div
              key={index}
              className={`card w-72 h-108 bg-white rounded-lg overflow-hidden shadow-2xl transition-all duration-500 ease-out opacity-0 cursor-pointer hover:transform hover:scale-105 hover:shadow-glow ${flippedCard === index ? "is-flipped" : ""}`}
              onClick={() => setFlippedCard(flippedCard === index ? null : index)}
            >
              <div className="relative w-full h-full transform-style-3d transition-transform duration-700">
                <div className="absolute inset-0 backface-hidden">
                  <Image
                    src={card.image || "/placeholder.svg"}
                    alt={card.title}
                    layout="fill"
                    objectFit="cover"
                    className="rounded-lg"
                  />
                </div>
                <div className="absolute inset-0 bg-primary p-6 text-white backface-hidden transform rotateY-180">
                  <h3 className="text-2xl font-semibold mb-4">{card.title}</h3>
                  <p className="text-lg">{card.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

