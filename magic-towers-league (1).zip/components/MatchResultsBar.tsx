"use client"

import * as React from "react"
import Image from "next/image"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Match {
  id: number
  date: string
  homeTeam: string
  awayTeam: string
  homeScore: number | null
  awayScore: number | null
  homeTeamLogo?: string
  awayTeamLogo?: string
}

interface MatchResultsBarProps {
  matches: Match[]
  onUpdateResult: (matchId: number, homeScore: number, awayScore: number) => void
}

export function MatchResultsBar({ matches, onUpdateResult }: MatchResultsBarProps) {
  const [selectedMatch, setSelectedMatch] = React.useState<Match | null>(null)
  const [homeScore, setHomeScore] = React.useState<string>("")
  const [awayScore, setAwayScore] = React.useState<string>("")

  const handleMatchClick = (match: Match) => {
    setSelectedMatch(match)
    setHomeScore(match.homeScore?.toString() || "")
    setAwayScore(match.awayScore?.toString() || "")
  }

  const handleSave = () => {
    if (selectedMatch && homeScore && awayScore) {
      onUpdateResult(selectedMatch.id, Number.parseInt(homeScore), Number.parseInt(awayScore))
      setSelectedMatch(null)
    }
  }

  return (
    <>
      <div className="bg-black bg-opacity-50 backdrop-blur-md border-b border-gray-800">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-between items-center overflow-x-auto">
            {matches.map((match) => (
              <button
                key={match.id}
                onClick={() => handleMatchClick(match)}
                className="flex items-center space-x-4 min-w-[200px] px-4 py-2 hover:bg-white hover:bg-opacity-10 rounded transition-colors"
              >
                <span className="text-sm text-gray-300">{match.date}</span>
                <div className="flex items-center">
                  <span className="font-bold">{match.homeScore ?? "-"}</span>
                  <span className="mx-1">:</span>
                  <span className="font-bold">{match.awayScore ?? "-"}</span>
                </div>
                <span className="text-sm truncate">
                  {match.homeTeam} vs {match.awayTeam}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <Dialog open={!!selectedMatch} onOpenChange={() => setSelectedMatch(null)}>
        <DialogContent className="sm:max-w-md glass-effect">
          <DialogHeader>
            <DialogTitle className="text-center neon-text" style={{ color: "var(--accent-blue)" }}>
              Spielergebnis eintragen
            </DialogTitle>
          </DialogHeader>
          {selectedMatch && (
            <div className="space-y-6">
              <div className="text-center text-sm text-gray-300">{selectedMatch.date}</div>
              <div className="grid grid-cols-[1fr,auto,1fr] gap-4 items-center">
                <div className="text-center space-y-2">
                  <div className="relative w-16 h-16 mx-auto">
                    <Image
                      src={selectedMatch.homeTeamLogo || "/placeholder.svg?height=64&width=64"}
                      alt={selectedMatch.homeTeam}
                      fill
                      className="object-contain"
                    />
                  </div>
                  <div className="font-semibold">{selectedMatch.homeTeam}</div>
                  <Input
                    type="number"
                    min="0"
                    value={homeScore}
                    onChange={(e) => setHomeScore(e.target.value)}
                    className="w-16 mx-auto text-center bg-black bg-opacity-50 text-white"
                  />
                </div>
                <div className="text-2xl font-bold">:</div>
                <div className="text-center space-y-2">
                  <div className="relative w-16 h-16 mx-auto">
                    <Image
                      src={selectedMatch.awayTeamLogo || "/placeholder.svg?height=64&width=64"}
                      alt={selectedMatch.awayTeam}
                      fill
                      className="object-contain"
                    />
                  </div>
                  <div className="font-semibold">{selectedMatch.awayTeam}</div>
                  <Input
                    type="number"
                    min="0"
                    value={awayScore}
                    onChange={(e) => setAwayScore(e.target.value)}
                    className="w-16 mx-auto text-center bg-black bg-opacity-50 text-white"
                  />
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setSelectedMatch(null)}
                  className="bg-black bg-opacity-50 text-white"
                >
                  Abbrechen
                </Button>
                <Button
                  onClick={handleSave}
                  className="bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:from-blue-600 hover:to-purple-600"
                >
                  Speichern
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}

