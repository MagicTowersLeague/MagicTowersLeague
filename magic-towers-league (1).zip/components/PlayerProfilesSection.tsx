"use client"

import { useState } from "react"
import Image from "next/image"

const players = [
  {
    id: 1,
    name: "Alice",
    avatar: "/placeholder.svg?height=200&width=200",
    rank: "Grandmaster",
    stats: { wins: 120, losses: 20, winRate: "85.7%" },
  },
  {
    id: 2,
    name: "Bob",
    avatar: "/placeholder.svg?height=200&width=200",
    rank: "Master",
    stats: { wins: 100, losses: 30, winRate: "76.9%" },
  },
  {
    id: 3,
    name: "Charlie",
    avatar: "/placeholder.svg?height=200&width=200",
    rank: "Expert",
    stats: { wins: 80, losses: 40, winRate: "66.7%" },
  },
  {
    id: 4,
    name: "Diana",
    avatar: "/placeholder.svg?height=200&width=200",
    rank: "Professional",
    stats: { wins: 75, losses: 45, winRate: "62.5%" },
  },
]

export function PlayerProfilesSection() {
  const [selectedPlayer, setSelectedPlayer] = useState(null)

  return (
    <section className="py-20 bg-gradient-to-b from-black to-primary">
      <div className="container mx-auto px-4">
        <h2 className="text-5xl font-bold text-center mb-16 text-white glow-text">Top Players</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {players.map((player) => (
            <div
              key={player.id}
              className="bg-primary rounded-lg overflow-hidden shadow-lg transition-all duration-300 hover:transform hover:scale-105 hover:shadow-glow cursor-pointer"
              onClick={() => setSelectedPlayer(player)}
            >
              <div className="relative h-64">
                <Image src={player.avatar || "/placeholder.svg"} alt={player.name} layout="fill" objectFit="cover" />
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-semibold mb-2 text-white">{player.name}</h3>
                <p className="text-accent">Rank: {player.rank}</p>
                <p className="text-gray-400">Wins: {player.stats.wins}</p>
                <p className="text-gray-400">Losses: {player.stats.losses}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {selectedPlayer && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-primary rounded-lg p-8 max-w-2xl w-full">
            <h2 className="text-4xl font-bold mb-6 text-white glow-text">{selectedPlayer.name}</h2>
            <div className="flex items-start">
              <div className="relative w-64 h-64 mr-8">
                <Image
                  src={selectedPlayer.avatar || "/placeholder.svg"}
                  alt={selectedPlayer.name}
                  layout="fill"
                  objectFit="cover"
                  className="rounded-lg"
                />
              </div>
              <div>
                <p className="text-2xl text-accent mb-4">Rank: {selectedPlayer.rank}</p>
                <p className="text-xl text-gray-300 mb-2">Wins: {selectedPlayer.stats.wins}</p>
                <p className="text-xl text-gray-300 mb-2">Losses: {selectedPlayer.stats.losses}</p>
                <p className="text-xl text-gray-300 mb-2">Win Rate: {selectedPlayer.stats.winRate}</p>
              </div>
            </div>
            <button
              className="mt-8 bg-accent text-black px-6 py-3 rounded-lg text-lg font-semibold hover:bg-white transition-colors duration-200"
              onClick={() => setSelectedPlayer(null)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </section>
  )
}

