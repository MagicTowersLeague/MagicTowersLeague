import { motion } from "framer-motion"

interface RuleSectionProps {
  title: string
  items: string[]
}

export function RuleSection({ title, items }: RuleSectionProps) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-indigo-900/30 backdrop-blur-sm rounded-lg p-6 shadow-lg"
    >
      <h2 className="text-2xl font-semibold mb-4 text-blue-300">{title}</h2>
      <ul className="list-disc list-inside space-y-2">
        {items.map((item, index) => (
          <motion.li
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="text-blue-100"
          >
            {item}
          </motion.li>
        ))}
      </ul>
    </motion.section>
  )
}

