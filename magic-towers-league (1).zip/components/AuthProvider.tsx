"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { getFirebaseAuth, getFirebaseAnalytics } from "@/lib/firebase"
import {
  type User,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  updateProfile,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  sendPasswordResetEmail as firebaseSendPasswordResetEmail,
} from "firebase/auth"
import { logEvent } from "firebase/analytics"
import { getFirestore, doc, setDoc, getDoc } from "firebase/firestore"
import { useToast } from "@/components/ui/use-toast"

import { FirebaseError } from "firebase/app"

interface AuthContextType {
  user: User | null
  profile: UserProfile | null
  signIn: (email: string, password: string) => Promise<void>
  signUp: (profileData: UserProfileData) => Promise<void>
  signUpTeamAdmin: (teamData: TeamAdminData) => Promise<void>
  signInWithGoogle: () => Promise<void>
  signOut: () => Promise<void>
  updateUserProfile: (profileData: Partial<UserProfile>) => Promise<void>
  isTeamAdmin: boolean
  sendPasswordResetEmail: (email: string) => Promise<void>
}

interface UserProfileData {
  email: string
  password: string
  name: string
}

interface TeamAdminData {
  email: string
  password: string
  teamName: string
}

interface UserProfile {
  uid: string
  email: string
  name: string
  role: "user" | "team-admin"
  teamName?: string
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  signIn: async () => {},
  signUp: async () => {},
  signUpTeamAdmin: async () => {},
  signInWithGoogle: async () => {},
  signOut: async () => {},
  updateUserProfile: async () => {},
  isTeamAdmin: false,
  sendPasswordResetEmail: async () => {},
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [isTeamAdmin, setIsTeamAdmin] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const auth = getFirebaseAuth()
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user)
      if (user) {
        const userProfile = await getUserProfile(user.uid)
        setProfile(userProfile)
        setIsTeamAdmin(userProfile?.role === "team-admin")
      } else {
        setProfile(null)
        setIsTeamAdmin(false)
      }
    })

    return () => unsubscribe()
  }, [])

  const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
    const db = getFirestore()
    const userDoc = await getDoc(doc(db, "users", uid))
    if (userDoc.exists()) {
      return userDoc.data() as UserProfile
    }
    return null
  }

  const signIn = async (email: string, password: string) => {
    const auth = getFirebaseAuth()
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password)
      console.log("Sign in successful:", userCredential.user.uid)
      const analytics = await getFirebaseAnalytics()
      if (analytics) {
        logEvent(analytics, "login", { method: "email" })
      }
    } catch (error) {
      console.error("Login error:", error)
      if (error instanceof FirebaseError) {
        switch (error.code) {
          case "auth/invalid-credential":
            throw new Error("Invalid email or password. Please check your credentials and try again.")
          case "auth/user-not-found":
            throw new Error("No user found with this email. Please check your email or sign up.")
          case "auth/wrong-password":
            throw new Error("Incorrect password. Please try again.")
          case "auth/user-disabled":
            throw new Error("This account has been disabled. Please contact support.")
          case "auth/too-many-requests":
            throw new Error("Too many unsuccessful login attempts. Please try again later.")
          default:
            throw new Error(`An error occurred during sign in: ${error.message}`)
        }
      } else {
        throw new Error("An unexpected error occurred. Please try again later.")
      }
    }
  }

  const signUp = async (profileData: UserProfileData) => {
    const auth = getFirebaseAuth()
    const db = getFirestore()

    const userCredential = await createUserWithEmailAndPassword(auth, profileData.email, profileData.password)
    await updateProfile(userCredential.user, {
      displayName: profileData.name,
    })

    const userProfile: UserProfile = {
      uid: userCredential.user.uid,
      email: profileData.email,
      name: profileData.name,
      role: "user",
    }

    await setDoc(doc(db, "users", userCredential.user.uid), userProfile)
    setProfile(userProfile)
    setIsTeamAdmin(false)

    const analytics = await getFirebaseAnalytics()
    if (analytics) {
      logEvent(analytics, "sign_up", { method: "email", role: "user" })
    }
  }

  const signUpTeamAdmin = async (teamData: TeamAdminData) => {
    const auth = getFirebaseAuth()
    const db = getFirestore()

    const userCredential = await createUserWithEmailAndPassword(auth, teamData.email, teamData.password)
    await updateProfile(userCredential.user, {
      displayName: teamData.teamName,
    })

    const userProfile: UserProfile = {
      uid: userCredential.user.uid,
      email: teamData.email,
      name: teamData.teamName,
      role: "team-admin",
      teamName: teamData.teamName,
    }

    await setDoc(doc(db, "users", userCredential.user.uid), userProfile)
    await setDoc(doc(db, "teams", userCredential.user.uid), {
      teamName: teamData.teamName,
      adminEmail: teamData.email,
      createdAt: new Date().toISOString(),
    })

    setProfile(userProfile)
    setIsTeamAdmin(true)

    const analytics = await getFirebaseAnalytics()
    if (analytics) {
      logEvent(analytics, "sign_up", { method: "email", role: "team-admin" })
    }
  }

  const signInWithGoogle = async () => {
    const auth = getFirebaseAuth()
    const provider = new GoogleAuthProvider()
    const userCredential = await signInWithPopup(auth, provider)
    const userProfile = await getUserProfile(userCredential.user.uid)
    if (userProfile) {
      setProfile(userProfile)
      setIsTeamAdmin(userProfile.role === "team-admin")
    } else {
      // If the user doesn't have a profile, create one as a normal user
      const newProfile: UserProfile = {
        uid: userCredential.user.uid,
        email: userCredential.user.email!,
        name: userCredential.user.displayName || "Unnamed User",
        role: "user",
      }
      await setDoc(doc(getFirestore(), "users", userCredential.user.uid), newProfile)
      setProfile(newProfile)
      setIsTeamAdmin(false)
    }
    const analytics = await getFirebaseAnalytics()
    if (analytics) {
      logEvent(analytics, "login", { method: "google" })
    }
  }

  const signOut = async () => {
    const auth = getFirebaseAuth()
    await firebaseSignOut(auth)
    setProfile(null)
    setIsTeamAdmin(false)
    toast({
      title: "Abgemeldet",
      description: "Sie wurden erfolgreich abgemeldet.",
    })
  }

  const updateUserProfile = async (profileData: Partial<UserProfile>) => {
    if (!user) return
    const db = getFirestore()
    await setDoc(doc(db, "users", user.uid), profileData, { merge: true })
    const updatedProfile = await getUserProfile(user.uid)
    if (updatedProfile) {
      setProfile(updatedProfile)
      setIsTeamAdmin(updatedProfile.role === "team-admin")
    }
  }

  const sendPasswordResetEmail = async (email: string) => {
    const auth = getFirebaseAuth()
    await firebaseSendPasswordResetEmail(auth, email)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        signIn,
        signUp,
        signUpTeamAdmin,
        signInWithGoogle,
        signOut,
        updateUserProfile,
        isTeamAdmin,
        sendPasswordResetEmail,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)

