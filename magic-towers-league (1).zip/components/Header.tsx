import Link from "next/link"
import Image from "next/image"

export function Header() {
  return (
    <header className="bg-gradient-to-r from-primary to-black text-white py-6 sticky top-0 z-50">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <div className="relative w-32 h-32 mr-4 logo-glow">
            <Image
              src="/placeholder.svg?height=128&width=128"
              alt="Magic Towers League Logo"
              width={128}
              height={128}
              className="object-contain"
            />
          </div>
          <span className="text-4xl font-bold glow-text">Magic Towers League</span>
        </Link>
        <nav>
          <ul className="flex space-x-8">
            {["Spielplan", "Tabelle", "Clubs", "Statistiken"].map((item) => (
              <li key={item}>
                <Link
                  href={`/${item.toLowerCase()}`}
                  className="text-xl hover:text-accent transition-colors duration-200 relative group"
                >
                  {item}
                  <span className="absolute left-0 right-0 bottom-0 h-0.5 bg-accent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-200"></span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  )
}

