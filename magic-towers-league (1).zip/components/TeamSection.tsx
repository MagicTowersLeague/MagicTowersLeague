"use client"

import Image from "next/image"
import Link from "next/link"
import { ChevronRight } from "lucide-react"

const teams = [
  { name: "Team Alpha", logo: "/placeholder.svg?height=64&width=64" },
  { name: "Team Beta", logo: "/placeholder.svg?height=64&width=64" },
  { name: "Team Gamma", logo: "/placeholder.svg?height=64&width=64" },
  { name: "Team Delta", logo: "/placeholder.svg?height=64&width=64" },
  { name: "Team Epsilon", logo: "/placeholder.svg?height=64&width=64" },
  { name: "Team Zeta", logo: "/placeholder.svg?height=64&width=64" },
]

export function TeamSection() {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-gray-900">CLUBS</h2>
          <Link href="/clubs" className="flex items-center text-blue-600 hover:text-blue-700">
            ALLE CLUBS
            <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          {teams.map((team) => (
            <Link
              key={team.name}
              href={`/clubs/${team.name.toLowerCase().replace(" ", "-")}`}
              className="flex items-center justify-center group"
            >
              <div className="relative w-16 h-16 transition-transform group-hover:scale-110">
                <Image src={team.logo || "/placeholder.svg"} alt={team.name} fill className="object-contain" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

