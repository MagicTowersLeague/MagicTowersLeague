"use client"

import { motion } from "framer-motion"
import { Trophy, Users, Target, Award } from "lucide-react"

const stats = [
  {
    icon: Trophy,
    value: "24",
    label: "Aktive Teams",
    color: "from-yellow-400 to-orange-500",
  },
  {
    icon: Users,
    value: "96+",
    label: "Aktive Spieler",
    color: "from-blue-400 to-purple-500",
  },
  {
    icon: Target,
    value: "1.2K",
    label: "Gespielte Matches",
    color: "from-green-400 to-emerald-500",
  },
  {
    icon: Award,
    value: "€50K",
    label: "Preisgelder",
    color: "from-red-400 to-pink-500",
  },
]

export function StatsSection() {
  return (
    <section className="py-16 bg-gradient-to-b from-blue-900/50 to-indigo-950/50">
      <div className="container mx-auto px-4">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
              <div className="relative bg-gradient-to-br from-indigo-900/50 to-blue-900/50 rounded-xl p-6 backdrop-blur-sm border border-blue-500/20">
                <div className={`inline-flex p-3 rounded-lg bg-gradient-to-br ${stat.color} mb-4`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-blue-200">{stat.label}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

