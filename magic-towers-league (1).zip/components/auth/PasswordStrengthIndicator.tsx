"use client"

import { Progress } from "@/components/ui/progress"

interface PasswordStrengthIndicatorProps {
  password: string
}

export function PasswordStrengthIndicator({ password }: PasswordStrengthIndicatorProps) {
  const getStrength = (password: string) => {
    let strength = 0
    if (password.length >= 8) strength += 25
    if (password.match(/[a-z]/)) strength += 25
    if (password.match(/[A-Z]/)) strength += 25
    if (password.match(/[0-9!@#$%^&*]/)) strength += 25
    return strength
  }

  const strength = getStrength(password)
  const getColor = () => {
    if (strength <= 25) return "bg-red-500"
    if (strength <= 50) return "bg-orange-500"
    if (strength <= 75) return "bg-yellow-500"
    return "bg-green-500"
  }

  return (
    <div className="space-y-2">
      <Progress value={strength} className={`h-2 ${getColor()}`} />
      <p className="text-xs text-muted-foreground">
        {strength <= 25 && "Sehr schwach"}
        {strength > 25 && strength <= 50 && "Schwach"}
        {strength > 50 && strength <= 75 && "Mittel"}
        {strength > 75 && "Stark"}
      </p>
    </div>
  )
}

