"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/AuthProvider"

export function CompleteProfile() {
  const [name, setName] = useState("")
  const [birthdate, setBirthdate] = useState("")
  const [city, setCity] = useState("")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [teamName, setTeamName] = useState("")
  const [isTeamAdmin, setIsTeamAdmin] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const { updateUserProfile } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    try {
      await updateUserProfile({
        name,
        birthdate,
        city,
        phoneNumber,
        role: isTeamAdmin ? "team-admin" : "player",
        ...(isTeamAdmin && { teamName }),
      })
      toast({
        title: "Profil vervollständigt",
        description: "Ihr Profil wurde erfolgreich aktualisiert.",
      })
      router.push("/dashboard")
    } catch (error) {
      setError(error instanceof Error ? error.message : "Ein unerwarteter Fehler ist aufgetreten.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full max-w-md space-y-6">
      <div className="space-y-2 text-center">
        <h1 className="text-2xl font-bold tracking-tight">Profil vervollständigen</h1>
        <p className="text-muted-foreground">Bitte vervollständigen Sie Ihr Profil, um fortzufahren.</p>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <RadioGroup defaultValue="player" onValueChange={(value) => setIsTeamAdmin(value === "team-admin")}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="player" id="player" />
            <Label htmlFor="player">Spieler</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="team-admin" id="team-admin" />
            <Label htmlFor="team-admin">Team-Admin</Label>
          </div>
        </RadioGroup>

        <div className="space-y-2">
          <Label htmlFor="name">Name</Label>
          <Input
            id="name"
            placeholder="Max Mustermann"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="birthdate">Geburtsdatum</Label>
          <Input id="birthdate" type="date" value={birthdate} onChange={(e) => setBirthdate(e.target.value)} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="city">Stadt</Label>
          <Input id="city" placeholder="Berlin" value={city} onChange={(e) => setCity(e.target.value)} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phoneNumber">Telefonnummer</Label>
          <Input
            id="phoneNumber"
            placeholder="+49 123 4567890"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            required
          />
        </div>
        {isTeamAdmin && (
          <div className="space-y-2">
            <Label htmlFor="teamName">Teamname</Label>
            <Input
              id="teamName"
              placeholder="Mustermann FC"
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              required
            />
          </div>
        )}

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? "Wird gespeichert..." : "Profil vervollständigen"}
        </Button>
      </form>
    </div>
  )
}

