"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Mail, Lock, Calendar, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/components/AuthProvider"
import { PasswordStrengthIndicator } from "@/components/auth/PasswordStrengthIndicator"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface AuthFormProps {
  isLogin: boolean
}

export function AuthForm({ isLogin }: { isLogin: boolean }) {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    phoneNumber: "",
    birthdate: "",
    city: "",
    district: "",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const { signIn, signUp, signInWithGoogle } = useAuth()
  const router = useRouter()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    try {
      if (isLogin) {
        await signIn(formData.email, formData.password)
      } else {
        await signUp({
          email: formData.email,
          password: formData.password,
          name: `${formData.firstName} ${formData.lastName}`,
          birthdate: formData.birthdate,
          city: formData.city,
          phoneNumber: formData.phoneNumber,
          district: formData.district,
          isTeamAdmin: false, // Setzen Sie dies auf true, wenn Sie die Option für Team-Admins hinzufügen
        })
      }
      router.push("/dashboard")
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message)
      } else {
        setError("An unexpected error occurred. Please try again later.")
      }
    } finally {
      setLoading(false)
    }
  }

  const handleGoogleSignIn = async () => {
    setLoading(true)
    try {
      await signInWithGoogle()
      router.push("/dashboard")
    } catch (error) {
      setError("Google-Anmeldung fehlgeschlagen. Bitte versuchen Sie es erneut.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <Alert variant="destructive" className="bg-red-900/50 border border-red-500 text-red-200">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {!isLogin && (
        <>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName" className="text-blue-200">
                Vorname
              </Label>
              <Input
                id="firstName"
                name="firstName"
                placeholder="Max"
                onChange={handleChange}
                required
                className="bg-indigo-900/50 border-indigo-700 text-blue-100 placeholder-blue-300"
              />
            </div>
            <div>
              <Label htmlFor="lastName" className="text-blue-200">
                Nachname
              </Label>
              <Input
                id="lastName"
                name="lastName"
                placeholder="Mustermann"
                onChange={handleChange}
                required
                className="bg-indigo-900/50 border-indigo-700 text-blue-100 placeholder-blue-300"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="phoneNumber" className="text-blue-200">
              Telefon
            </Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-300" />
              <Input
                id="phoneNumber"
                name="phoneNumber"
                type="tel"
                placeholder="+49 123 4567890"
                onChange={handleChange}
                required
                className="pl-10 bg-indigo-900/50 border-indigo-700 text-blue-100 placeholder-blue-300"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="birthdate" className="text-blue-200">
              Geburtsdatum
            </Label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-300" />
              <Input
                id="birthdate"
                name="birthdate"
                type="date"
                onChange={handleChange}
                required
                className="pl-10 bg-indigo-900/50 border-indigo-700 text-blue-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="city" className="text-blue-200">
                Stadt
              </Label>
              <Input
                id="city"
                name="city"
                placeholder="Berlin"
                onChange={handleChange}
                required
                className="bg-indigo-900/50 border-indigo-700 text-blue-100 placeholder-blue-300"
              />
            </div>
            <div>
              <Label htmlFor="district" className="text-blue-200">
                Landkreis
              </Label>
              <Input
                id="district"
                name="district"
                placeholder="Mitte"
                onChange={handleChange}
                required
                className="bg-indigo-900/50 border-indigo-700 text-blue-100 placeholder-blue-300"
              />
            </div>
          </div>
        </>
      )}

      <div>
        <Label htmlFor="email" className="text-blue-200">
          E-Mail
        </Label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-300" />
          <Input
            id="email"
            name="email"
            type="email"
            placeholder="max@beispiel.de"
            onChange={handleChange}
            required
            className="pl-10 bg-indigo-900/50 border-indigo-700 text-blue-100 placeholder-blue-300"
          />
        </div>
      </div>

      <div>
        <Label htmlFor="password" className="text-blue-200">
          Passwort
        </Label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-300" />
          <Input
            id="password"
            name="password"
            type="password"
            placeholder="Mindestens 8 Zeichen"
            onChange={handleChange}
            required
            className="pl-10 bg-indigo-900/50 border-indigo-700 text-blue-100 placeholder-blue-300"
          />
        </div>
        {!isLogin && <PasswordStrengthIndicator password={formData.password} />}
      </div>

      {!isLogin && (
        <div>
          <Label htmlFor="confirmPassword" className="text-blue-200">
            Passwort bestätigen
          </Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-300" />
            <Input
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              placeholder="Passwort wiederholen"
              onChange={handleChange}
              required
              className="pl-10 bg-indigo-900/50 border-indigo-700 text-blue-100 placeholder-blue-300"
            />
          </div>
        </div>
      )}

      <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white" disabled={loading}>
        {loading ? "Lädt..." : isLogin ? "Anmelden" : "Registrieren"}
      </Button>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-indigo-700"></span>
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-2 bg-indigo-950 text-blue-300">Oder</span>
        </div>
      </div>

      <Button
        type="button"
        onClick={handleGoogleSignIn}
        variant="outline"
        className="w-full border-indigo-700 text-blue-300 hover:bg-indigo-900/50"
      >
        Mit Google fortfahren
      </Button>
    </form>
  )
}

