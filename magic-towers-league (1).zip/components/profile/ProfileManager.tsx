"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/AuthProvider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/components/ui/use-toast"

export function ProfileManager() {
  const { profile, updateUserProfile } = useAuth()
  const [displayName, setDisplayName] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = (useState = useState(""))
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const { toast } = useToast()

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName)
    }
  }, [profile])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    try {
      await updateUserProfile({ displayName })
      toast({
        title: "Profil aktualisiert",
        description: "Ihre Änderungen wurden erfolgreich gespeichert.",
      })
    } catch (error) {
      setError(error instanceof Error ? error.message : "Ein unerwarteter Fehler ist aufgetreten.")
    } finally {
      setLoading(false)
    }
  }

  if (!profile) {
    return <div>Laden...</div>
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Profil verwalten</h2>
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="displayName">Anzeigename</Label>
          <Input id="displayName" value={displayName} onChange={(e) => setDisplayName(e.target.value)} required />
        </div>
        <Button type="submit" disabled={loading}>
          {loading ? "Speichern..." : "Änderungen speichern"}
        </Button>
      </form>
    </div>
  )
}

