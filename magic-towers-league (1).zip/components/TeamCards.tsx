"use client"

import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import { Text, useTexture } from "@react-three/drei"
import * as THREE from "three"

interface Team {
  id: number
  name: string
  logo: string
  position: number
  points: number
}

interface TeamCardsProps {
  teams: Team[]
  spread: boolean
}

export function TeamCards({ teams, spread }: TeamCardsProps) {
  const groupRef = useRef<THREE.Group>(null!)

  useFrame(() => {
    if (groupRef.current) {
      groupRef.current.rotation.y += 0.005
    }
  })

  return (
    <group ref={groupRef}>
      {teams.map((team, index) => (
        <TeamCard key={team.id} team={team} index={index} spread={spread} />
      ))}
    </group>
  )
}

function TeamCard({ team, index, spread }: { team: Team; index: number; spread: boolean }) {
  const meshRef = useRef<THREE.Mesh>(null!)
  const texture = useTexture(team.logo)
  texture.encoding = THREE.sRGBEncoding

  useFrame(() => {
    if (meshRef.current) {
      const targetX = spread ? (index - 3) * 2 : 0
      meshRef.current.position.x = THREE.MathUtils.lerp(meshRef.current.position.x, targetX, 0.05)
      meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, spread ? 0 : Math.PI / 2, 0.05)
    }
  })

  const isTopTeam = index === 0

  return (
    <mesh ref={meshRef} position={[0, 0, index * 0.01]} scale={[1.5, 2, 0.1]}>
      <boxGeometry />
      <meshPhysicalMaterial
        color={isTopTeam ? "gold" : "white"}
        metalness={0.5}
        roughness={0.2}
        transmission={0.9}
        thickness={0.5}
        envMapIntensity={1}
      />

      <Text
        position={[0, -0.7, 0.06]}
        fontSize={0.15}
        color={isTopTeam ? "gold" : "white"}
        anchorX="center"
        anchorY="middle"
        font="/fonts/Geist-Bold.ttf"
      >
        {team.name}
      </Text>

      <Text
        position={[0, -0.9, 0.06]}
        fontSize={0.12}
        color={isTopTeam ? "gold" : "white"}
        anchorX="center"
        anchorY="middle"
        font="/fonts/Geist-Regular.ttf"
      >
        {`#${team.position} - ${team.points} Pts`}
      </Text>

      <mesh position={[0, 0.3, 0.06]} scale={[0.8, 0.8, 0.1]}>
        <planeGeometry />
        <meshBasicMaterial map={texture} transparent opacity={0.9} />
      </mesh>
    </mesh>
  )
}

