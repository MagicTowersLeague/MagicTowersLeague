"use client"

import Link from "next/link"
import { LanguageSelector } from "@/components/LanguageSelector"

export function TopNav() {
  return (
    <div className="bg-indigo-950 text-gray-300 text-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-10">
          <div className="flex items-center space-x-4">
            <LanguageSelector />
            <Link href="/broadcaster" className="hover:text-white">
              BROADCASTER
            </Link>
            <Link href="/mitfahrportal" className="hover:text-white">
              MITFAHRPORTAL
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/app" className="text-red-500 hover:text-red-400">
              MAGIC TOWERS APP
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

