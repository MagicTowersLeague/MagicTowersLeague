"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback } from "react"

interface SidebarContextType {
  isOpen: boolean
  toggleSidebar: (value?: boolean) => void
}

const SidebarContext = createContext<SidebarContextType>({
  isOpen: false,
  toggleSidebar: () => {},
})

export function SidebarProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false)

  const toggleSidebar = useCallback((value?: boolean) => {
    setIsOpen((prev) => value ?? !prev)
  }, [])

  return <SidebarContext.Provider value={{ isOpen, toggleSidebar }}>{children}</SidebarContext.Provider>
}

export const useSidebar = () => useContext(SidebarContext)

