import Image from "next/image"

interface Player {
  id: number
  name: string
  avatar: string
  team: string
  stats: {
    wins: number
    losses: number
    winRate: string
  }
}

interface PlayerCardsProps {
  players: Player[]
  spread: boolean
}

export function PlayerCards({ players, spread }: PlayerCardsProps) {
  return (
    <div
      className={`flex justify-center items-center transition-all duration-1000 ${spread ? "space-x-4" : "space-x-0"}`}
    >
      {players.map((player, index) => (
        <div
          key={player.id}
          className={`glass-effect w-64 p-4 transition-all duration-500 hover-scale ${
            spread ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
          style={{
            transitionDelay: `${index * 100}ms`,
            borderColor: index === 0 ? "var(--accent-blue)" : "rgba(255, 255, 255, 0.2)",
          }}
        >
          <div className="relative w-full h-48 mb-4 overflow-hidden rounded-lg">
            <Image src={player.avatar || "/placeholder.svg"} alt={player.name} layout="fill" objectFit="cover" />
          </div>
          <h3
            className="text-lg font-bold mb-2 neon-text"
            style={{ color: index === 0 ? "var(--accent-blue)" : "var(--text-primary)" }}
          >
            {player.name}
          </h3>
          <p className="text-sm text-gray-300 mb-4">{player.team}</p>
          <div className="flex justify-between text-sm">
            <span>Siege: {player.stats.wins}</span>
            <span>Niederlagen: {player.stats.losses}</span>
          </div>
          <div className="mt-2 text-sm">
            <span>Gewinnrate: {player.stats.winRate}</span>
          </div>
        </div>
      ))}
    </div>
  )
}

