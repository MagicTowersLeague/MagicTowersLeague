export default function Standings() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Tabelle</h1>
      <p className="mb-4">Hier sehen Sie die aktuelle Tabelle der Magic Towers League.</p>
      {/* Hier kommt später die Tabelle mit den Standings */}
    </div>
  )
}

