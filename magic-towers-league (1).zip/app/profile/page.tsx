"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { useAuth } from "@/components/AuthProvider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { getFirestore, doc, getDoc, setDoc } from "firebase/firestore"
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage"
import { useOnlineStatus } from "@/hooks/useOnlineStatus"

export default function ProfilePage() {
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [email, setEmail] = useState("")
  const [teamName, setTeamName] = useState("")
  const [profilePicture, setProfilePicture] = useState<File | null>(null)
  const [profilePictureUrl, setProfilePictureUrl] = useState("")
  const [loading, setLoading] = useState(false)
  const isOnline = useOnlineStatus()
  const { user, updateUserProfile } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const loadProfileData = useCallback(async () => {
    if (!user) return

    try {
      const db = getFirestore()
      const userDoc = await getDoc(doc(db, "users", user.uid))
      if (userDoc.exists()) {
        const data = userDoc.data()
        setFirstName(data.firstName || "")
        setLastName(data.lastName || "")
        setEmail(data.email || "")
        setTeamName(data.teamName || "")
        setProfilePictureUrl(data.profilePictureUrl || "")
      }
    } catch (error) {
      console.error("Error loading profile data:", error)
      toast({
        title: "Fehler beim Laden",
        description: "Ihre Profildaten konnten nicht geladen werden. Bitte überprüfen Sie Ihre Internetverbindung.",
        variant: "destructive",
      })
    }
  }, [user, toast])

  useEffect(() => {
    if (user && isOnline) {
      loadProfileData()
    } else if (!user) {
      router.push("/login")
    }
  }, [user, router, isOnline, loadProfileData])

  const handleProfilePictureChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setProfilePicture(e.target.files[0])
      setProfilePictureUrl(URL.createObjectURL(e.target.files[0]))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !isOnline) {
      toast({
        title: "Offline",
        description: "Sie sind offline. Bitte stellen Sie eine Internetverbindung her und versuchen Sie es erneut.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      // Update email if changed
      if (email !== user.email) {
        await user.updateEmail(email)
      }

      // Upload profile picture if selected
      let newProfilePictureUrl = profilePictureUrl
      if (profilePicture) {
        const storage = getStorage()
        const storageRef = ref(storage, `profile-pictures/${user.uid}`)
        await uploadBytes(storageRef, profilePicture)
        newProfilePictureUrl = await getDownloadURL(storageRef)
      }

      // Update profile in Firestore
      const db = getFirestore()
      await setDoc(
        doc(db, "users", user.uid),
        {
          firstName,
          lastName,
          email,
          teamName,
          profilePictureUrl: newProfilePictureUrl,
        },
        { merge: true },
      )

      // Update local auth context
      await updateUserProfile({
        displayName: `${firstName} ${lastName}`,
        email,
        photoURL: newProfilePictureUrl,
      })

      toast({
        title: "Erfolg",
        description: "Ihr Profil wurde erfolgreich aktualisiert.",
      })
    } catch (error) {
      console.error("Fehler beim Aktualisieren des Profils:", error)
      toast({
        title: "Fehler",
        description: "Es gab ein Problem beim Aktualisieren Ihres Profils. Bitte versuchen Sie es erneut.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (!user) {
    return null // or a loading spinner
  }

  if (!isOnline) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Profil</h1>
        <p className="text-red-500">
          Sie sind offline. Bitte stellen Sie eine Internetverbindung her, um Ihr Profil zu bearbeiten.
        </p>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Profil</h1>
      <form onSubmit={handleSubmit} className="space-y-6 max-w-md">
        <div>
          <Label htmlFor="profilePicture">Profilbild</Label>
          <div className="mt-2 flex items-center space-x-4">
            <Image
              src={profilePictureUrl || "/placeholder.svg"}
              alt="Profilbild"
              width={100}
              height={100}
              className="rounded-full object-cover"
            />
            <Input id="profilePicture" type="file" onChange={handleProfilePictureChange} accept="image/*" />
          </div>
        </div>
        <div>
          <Label htmlFor="firstName">Vorname</Label>
          <Input id="firstName" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="lastName">Nachname</Label>
          <Input id="lastName" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="email">E-Mail</Label>
          <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="teamName">Team Name</Label>
          <Input id="teamName" value={teamName} onChange={(e) => setTeamName(e.target.value)} />
        </div>
        <Button type="submit" disabled={loading}>
          {loading ? "Wird gespeichert..." : "Profil speichern"}
        </Button>
      </form>
    </div>
  )
}

