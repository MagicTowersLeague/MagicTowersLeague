"use client"
import { HeroSection } from "@/components/HeroSection"
import { UpcomingMatches } from "@/components/UpcomingMatches"
import { FeaturedTeams } from "@/components/FeaturedTeams"
import { NewsSection } from "@/components/NewsSection"
import { StatsSection } from "@/components/StatsSection"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-blue-900 to-indigo-950">
      <main>
        <HeroSection />
        <UpcomingMatches />
        <FeaturedTeams />
        <NewsSection />
        <StatsSection />
      </main>
    </div>
  )
}

