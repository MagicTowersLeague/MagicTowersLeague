"use client"

import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { TopNav } from "@/components/TopNav"
import { Sidebar } from "@/components/Sidebar"
import { AuthProvider } from "@/components/AuthProvider"
import { SidebarProvider } from "@/components/SidebarProvider"
import { Toaster } from "@/components/ui/toaster"
import { initializeFirebase } from "@/lib/firebase"
import { useState } from "react"
import { CriticalError } from "@/components/CriticalError"

const inter = Inter({ subsets: ["latin"] })

if (typeof window !== "undefined") {
  try {
    initializeFirebase()
  } catch (error) {
    console.error("Failed to initialize Firebase:", error)
    // You might want to add some UI feedback here for critical errors
  }
}

export const metadata: Metadata = {
  title: "Magic Towers League",
  description: "Professional Magic Towers League Platform",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [criticalError, setCriticalError] = useState<string | null>(null)

  if (typeof window !== "undefined") {
    try {
      initializeFirebase()
    } catch (error) {
      console.error("Failed to initialize Firebase:", error)
      setCriticalError("Failed to initialize essential services. Please try again later.")
    }
  }

  if (criticalError) {
    return (
      <html lang="de">
        <body className={inter.className}>
          <div className="container mx-auto px-4 py-8">
            <CriticalError message={criticalError} />
          </div>
        </body>
      </html>
    )
  }

  return (
    <html lang="de">
      <body className={inter.className}>
        <AuthProvider>
          <SidebarProvider>
            <div className="flex min-h-screen">
              <Sidebar />
              <div className="flex-1 flex flex-col">
                <TopNav />
                <main className="flex-1">{children}</main>
              </div>
            </div>
            <Toaster />
          </SidebarProvider>
        </AuthProvider>
      </body>
    </html>
  )
}



import './globals.css'