import type { Metadata } from "next"
import TeamsList from "./TeamsList"

export const metadata: Metadata = {
  title: "Teams | Magic Towers League",
  description: "Übersicht aller Teams in der Magic Towers League",
}

export default function TeamsPage() {
  return <TeamsList />
}

