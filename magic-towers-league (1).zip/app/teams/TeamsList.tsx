"use client"

import { useState, useEffect } from "react"
import { getFirestore, collection, getDocs } from "firebase/firestore"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

async function getTeams() {
  const db = getFirestore()
  const teamsCollection = collection(db, "teams")
  const teamSnapshot = await getDocs(teamsCollection)
  return teamSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }))
}

export default function TeamsList() {
  const [teams, setTeams] = useState([])

  useEffect(() => {
    getTeams().then(setTeams)
  }, [])

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Teams</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {teams.map((team: any) => (
          <Card key={team.id}>
            <CardHeader>
              <CardTitle>{team.teamName}</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                <strong>Spieler:</strong> {team.playerName}
              </p>
              <p>
                <strong>E-Mail:</strong> {team.email}
              </p>
              <p>
                <strong>Telefon:</strong> {team.phone}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

