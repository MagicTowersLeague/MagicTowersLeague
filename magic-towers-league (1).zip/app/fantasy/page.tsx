"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Beispiel-Daten für verfügbare Spieler
const availablePlayers = [
  { id: 1, name: "Max Mustermann", team: "Phoenix Gaming", position: "Angreifer", price: 1000000, points: 120 },
  { id: 2, name: "Lisa Schmidt", team: "Dragon Warriors", position: "Verteidiger", price: 950000, points: 105 },
  { id: 3, name: "Tom Müller", team: "Neon Knights", position: "Mittelfeld", price: 1200000, points: 150 },
  // ... weitere Spieler
]

export default function FantasyManager() {
  const [budget, setBudget] = useState(5000000) // 5 Millionen Budget
  const [myTeam, setMyTeam] = useState<typeof availablePlayers>([])
  const [searchTerm, setSearchTerm] = useState("")

  const filteredPlayers = availablePlayers.filter(
    (player) =>
      player.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      !myTeam.some((teamPlayer) => teamPlayer.id === player.id),
  )

  const addPlayer = (player: (typeof availablePlayers)[0]) => {
    if (budget >= player.price && myTeam.length < 5) {
      setMyTeam([...myTeam, player])
      setBudget(budget - player.price)
    }
  }

  const removePlayer = (player: (typeof availablePlayers)[0]) => {
    setMyTeam(myTeam.filter((p) => p.id !== player.id))
    setBudget(budget + player.price)
  }

  const totalPoints = myTeam.reduce((sum, player) => sum + player.points, 0)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">Magic Towers Fantasy Manager</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Verfügbare Spieler</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <Label htmlFor="search">Spieler suchen:</Label>
              <Input
                id="search"
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Spielername eingeben..."
              />
            </div>
            <div className="space-y-2">
              {filteredPlayers.map((player) => (
                <div key={player.id} className="flex justify-between items-center p-2 bg-gray-100 rounded">
                  <div className="flex items-center space-x-2">
                    <Avatar>
                      <AvatarImage src={`/placeholder.svg?height=40&width=40&text=${player.name[0]}`} />
                      <AvatarFallback>{player.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{player.name}</p>
                      <p className="text-sm text-gray-600">
                        {player.team} - {player.position}
                      </p>
                    </div>
                  </div>
                  <Button onClick={() => addPlayer(player)} disabled={budget < player.price || myTeam.length >= 5}>
                    Hinzufügen (€{player.price / 1000000}M)
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Mein Team</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">Budget: €{budget / 1000000}M</p>
            <p className="mb-4">Gesamtpunkte: {totalPoints}</p>
            <div className="space-y-2">
              {myTeam.map((player) => (
                <div key={player.id} className="flex justify-between items-center p-2 bg-gray-100 rounded">
                  <div className="flex items-center space-x-2">
                    <Avatar>
                      <AvatarImage src={`/placeholder.svg?height=40&width=40&text=${player.name[0]}`} />
                      <AvatarFallback>{player.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{player.name}</p>
                      <p className="text-sm text-gray-600">
                        {player.team} - {player.position}
                      </p>
                    </div>
                  </div>
                  <Button variant="destructive" onClick={() => removePlayer(player)}>
                    Entfernen
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

