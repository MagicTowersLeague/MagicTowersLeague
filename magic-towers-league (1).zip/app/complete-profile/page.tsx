import { CompleteProfile } from "@/components/auth/CompleteProfile"

export default function CompleteProfilePage() {
  return (
    <div className="container flex h-screen w-screen flex-col items-center justify-center">
      <CompleteProfile />
    </div>
  )
}

