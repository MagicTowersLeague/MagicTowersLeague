"use client"

import { useState } from "react"

const districts = [
  "Alb-Donau-Kreis",
  "Baden-Baden",
  "Biberach",
  "Bodenseekreis",
  "Böblingen",
  "Breisgau-Hochschwarzwald",
  "Calw",
  "Emmendingen",
  "Enzkreis",
  "Esslingen",
  "Freiburg im Breisgau",
  "Freudenstadt",
  "Göppingen",
  "Heidelberg",
  "Heidenheim",
  "Heilbronn",
  "Hohenlohekreis",
  "Karlsruhe",
  "Konstanz",
  "Lörrach",
  "Ludwigsburg",
  "Main-Tauber-Kreis",
  "Mannheim",
  "Neckar-Odenwald-Kreis",
  "Ortenaukreis",
  "Ostalbkreis",
  "Pforzheim",
  "Rastatt",
  "Ravensburg",
  "Rems-Murr-Kreis",
  "Reutlingen",
  "Rhein-Neckar-Kreis",
  "Rottweil",
  "Schwäbisch Hall",
  "Schwarzwald-Baar-Kreis",
  "Sigmaringen",
  "Stuttgart",
  "Tübingen",
  "Tuttlingen",
  "Ulm",
  "Waldshut",
  "Zollernalbkreis",
]

export default function Leagues() {
  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null)

  const getTeamsForDistrict = (district: string) => {
    return [
      { id: 1, name: "Team A" },
      { id: 2, name: "Team B" },
      { id: 3, name: "Team C" },
    ]
  }

  return (
    <div className="container mx-auto px-4">
      <h1 className="text-3xl font-bold mb-6 text-[#1E90FF]">Ligen in Baden-Württemberg</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {districts.map((district) => (
          <button
            key={district}
            className="p-4 bg-[#1E90FF] text-white rounded-lg hover:bg-[#FF4500] transition-colors"
            onClick={() => setSelectedDistrict(district)}
          >
            {district}
          </button>
        ))}
      </div>
      {selectedDistrict && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4 text-[#1E90FF]">Teams in {selectedDistrict}</h2>
          <ul className="list-disc list-inside space-y-2">
            {getTeamsForDistrict(selectedDistrict).map((team) => (
              <li key={team.id} className="text-[#000000] hover:text-[#FF4500] transition-colors">
                {team.name}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

