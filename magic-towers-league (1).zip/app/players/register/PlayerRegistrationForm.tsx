"use client"

export default function PlayerRegistrationForm() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Spieler Registrierung</h1>
      <p className="mb-4">Registrieren Sie sich hier als Einzelspieler für die Magic Towers League.</p>
      {/* Hier kommt später das Registrierungsformular */}
    </div>
  )
}

