import type { Metadata } from "next"
import PlayerRegistrationForm from "./PlayerRegistrationForm"

export const metadata: Metadata = {
  title: "Spieler Registrierung | Magic Towers League",
  description: "Registrieren Sie sich als Einzelspieler für die Magic Towers League",
}

export default function PlayerRegistrationPage() {
  return <PlayerRegistrationForm />
}

