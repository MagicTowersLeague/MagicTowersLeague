"use client"

import { useState } from "react"
import { DashboardNav } from "@/components/dashboard/DashboardNav"
import { DashboardHeader } from "@/components/dashboard/DashboardHeader"
import { StatsCards } from "@/components/dashboard/StatsCards"
import { RevenueChart } from "@/components/dashboard/RevenueChart"
import { UsersChart } from "@/components/dashboard/UsersChart"
import { RecentActivity } from "@/components/dashboard/RecentActivity"
import { UserMap } from "@/components/dashboard/UserMap"

export default function DashboardPage() {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div className="min-h-screen bg-[#0F1117] text-white">
      <DashboardNav collapsed={collapsed} setCollapsed={setCollapsed} />
      <main className={`transition-all duration-300 ${collapsed ? "ml-20" : "ml-64"}`}>
        <DashboardHeader />
        <div className="p-8">
          <StatsCards />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
            <RevenueChart />
            <UsersChart />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
            <RecentActivity />
            <UserMap />
          </div>
        </div>
      </main>
    </div>
  )
}

