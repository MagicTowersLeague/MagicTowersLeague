"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/AuthProvider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { getFirestore, doc, setDoc } from "firebase/firestore"
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage"

export default function TeamErstellen() {
  const [teamName, setTeamName] = useState("")
  const [teamLogo, setTeamLogo] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const { user } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) {
      toast({
        title: "Fehler",
        description: "Sie müssen angemeldet sein, um ein Team zu erstellen.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      const db = getFirestore()
      const storage = getStorage()
      const teamId = user.uid

      // Team in Firestore speichern
      await setDoc(doc(db, "teams", teamId), {
        teamName: teamName,
        adminEmail: user.email,
        role: "team-admin",
        createdAt: new Date().toISOString(),
      })

      // Team-Logo hochladen, wenn vorhanden
      if (teamLogo) {
        const storageRef = ref(storage, `team-logos/${teamId}`)
        await uploadBytes(storageRef, teamLogo)
        const logoUrl = await getDownloadURL(storageRef)

        // Logo-URL zum Team-Dokument hinzufügen
        await setDoc(doc(db, "teams", teamId), { logoUrl }, { merge: true })
      }

      toast({
        title: "Erfolg",
        description: "Ihr Team wurde erfolgreich erstellt.",
      })
      router.push("/dashboard")
    } catch (error) {
      console.error("Fehler beim Erstellen des Teams:", error)
      toast({
        title: "Fehler",
        description: "Es gab ein Problem beim Erstellen des Teams. Bitte versuchen Sie es erneut.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-4">Bitte melden Sie sich an, um ein Team zu erstellen.</h1>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Team erstellen</h1>
      <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
        <div>
          <Label htmlFor="teamName">Teamname</Label>
          <Input id="teamName" value={teamName} onChange={(e) => setTeamName(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="teamLogo">Team Logo (optional)</Label>
          <Input
            id="teamLogo"
            type="file"
            onChange={(e) => setTeamLogo(e.target.files ? e.target.files[0] : null)}
            accept="image/*"
          />
        </div>
        <Button type="submit" disabled={loading}>
          {loading ? "Wird erstellt..." : "Team erstellen"}
        </Button>
      </form>
    </div>
  )
}

