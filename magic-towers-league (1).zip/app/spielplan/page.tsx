"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Match {
  id: number
  date: string
  time: string
  homeTeam: {
    name: string
    logo: string
  }
  awayTeam: {
    name: string
    logo: string
  }
  homeScore: number | null
  awayScore: number | null
  location: string
}

const initialMatches: Match[] = [
  {
    id: 1,
    date: "07.02.2024",
    time: "19:30",
    homeTeam: {
      name: "Team A",
      logo: "/placeholder.svg?height=40&width=40",
    },
    awayTeam: {
      name: "Team B",
      logo: "/placeholder.svg?height=40&width=40",
    },
    homeScore: null,
    awayScore: null,
    location: "Stadion A",
  },
  {
    id: 2,
    date: "08.02.2024",
    time: "15:30",
    homeTeam: {
      name: "Team C",
      logo: "/placeholder.svg?height=40&width=40",
    },
    awayTeam: {
      name: "Team D",
      logo: "/placeholder.svg?height=40&width=40",
    },
    homeScore: null,
    awayScore: null,
    location: "Stadion B",
  },
  // Add more matches as needed
]

export default function Spielplan() {
  const [matches, setMatches] = useState<Match[]>(initialMatches)
  const [editMode, setEditMode] = useState(false)

  const handleScoreChange = (matchId: number, team: "home" | "away", score: string) => {
    setMatches(
      matches.map((match) => {
        if (match.id === matchId) {
          return {
            ...match,
            [team === "home" ? "homeScore" : "awayScore"]: score === "" ? null : Number.parseInt(score),
          }
        }
        return match
      }),
    )
  }

  const handleSave = () => {
    setEditMode(false)
    // Here you would typically save to a database
    console.log("Saved matches:", matches)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Spielplan</h1>
        <div className="space-x-2">
          <Button variant="outline" onClick={() => setEditMode(!editMode)}>
            {editMode ? "Bearbeitung abbrechen" : "Ergebnisse bearbeiten"}
          </Button>
          {editMode && (
            <Button className="bg-[#E4002B] hover:bg-[#b30022]" onClick={handleSave}>
              Änderungen speichern
            </Button>
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Datum
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Zeit</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Heimteam
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ergebnis
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Auswärtsteam
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Spielort
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {matches.map((match) => (
                <tr key={match.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{match.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{match.time}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="relative flex-shrink-0 w-8 h-8 mr-2">
                        <Image
                          src={match.homeTeam.logo || "/placeholder.svg"}
                          alt={match.homeTeam.name}
                          fill
                          className="object-contain"
                        />
                      </div>
                      <div className="text-sm font-medium text-gray-900">{match.homeTeam.name}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <div className="flex items-center justify-center space-x-2">
                      {editMode ? (
                        <>
                          <Input
                            type="number"
                            min="0"
                            value={match.homeScore ?? ""}
                            onChange={(e) => handleScoreChange(match.id, "home", e.target.value)}
                            className="w-16 text-center"
                          />
                          <span className="text-gray-500">:</span>
                          <Input
                            type="number"
                            min="0"
                            value={match.awayScore ?? ""}
                            onChange={(e) => handleScoreChange(match.id, "away", e.target.value)}
                            className="w-16 text-center"
                          />
                        </>
                      ) : (
                        <span className="text-sm font-medium">
                          {match.homeScore ?? "-"} : {match.awayScore ?? "-"}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="relative flex-shrink-0 w-8 h-8 mr-2">
                        <Image
                          src={match.awayTeam.logo || "/placeholder.svg"}
                          alt={match.awayTeam.name}
                          fill
                          className="object-contain"
                        />
                      </div>
                      <div className="text-sm font-medium text-gray-900">{match.awayTeam.name}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{match.location}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

