"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { AuthForm } from "@/components/auth/AuthForm"
import Image from "next/image"

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true)

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-950 via-blue-900 to-indigo-950">
      <div className="w-full max-w-6xl flex rounded-xl shadow-2xl overflow-hidden">
        {/* Left side - Image and Branding */}
        <motion.div
          className="hidden lg:block w-1/2 relative"
          initial={{ x: -100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          <Image
            src="/placeholder.svg?height=1080&width=1080"
            alt="Magic Towers League"
            layout="fill"
            objectFit="cover"
            className="rounded-l-xl"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-950/70 via-blue-900/70 to-indigo-950/70 flex flex-col justify-center items-center text-white p-12">
            <h1 className="text-4xl font-bold mb-4 text-blue-300">Magic Towers League</h1>
            <p className="text-xl text-center text-blue-100">
              Treten Sie der ultimativen Gaming-Community bei und werden Sie Teil der Legende!
            </p>
          </div>
        </motion.div>

        {/* Right side - Auth Form */}
        <motion.div
          className="w-full lg:w-1/2 bg-indigo-950/80 p-12 backdrop-blur-sm"
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          <div className="mb-8 text-center">
            <h2 className="text-3xl font-bold text-blue-300">
              {isLogin ? "Willkommen zurück!" : "Erstellen Sie Ihr Konto"}
            </h2>
            <p className="text-blue-100 mt-2">
              {isLogin
                ? "Melden Sie sich an, um Ihre Abenteuer fortzusetzen."
                : "Registrieren Sie sich und starten Sie Ihre Reise."}
            </p>
          </div>

          <AuthForm isLogin={isLogin} />

          <div className="mt-8 text-center">
            <p className="text-blue-200">
              {isLogin ? "Noch kein Konto?" : "Bereits registriert?"}
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="ml-2 text-blue-400 hover:text-blue-300 font-semibold"
              >
                {isLogin ? "Registrieren" : "Anmelden"}
              </button>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

