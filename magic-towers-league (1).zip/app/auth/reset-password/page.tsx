"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/components/ui/use-toast"
import { getFirebaseAuth } from "@/lib/firebase"
import { sendPasswordResetEmail } from "firebase/auth"

export default function ResetPasswordPage() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    try {
      const auth = getFirebaseAuth()
      await sendPasswordResetEmail(auth, email)
      setSuccess(true)
      toast({
        title: "E-Mail gesendet",
        description: "Bitte überprüfen Sie Ihren Posteingang und folgen Sie den Anweisungen.",
      })
    } catch (error) {
      setError(
        error instanceof Error
          ? error.message
          : "Ein unerwarteter Fehler ist aufgetreten. Bitte versuchen Sie es später erneut.",
      )
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="container flex h-screen w-screen flex-col items-center justify-center">
        <div className="w-full max-w-md space-y-6">
          <div className="space-y-2 text-center">
            <h1 className="text-2xl font-bold tracking-tight">E-Mail gesendet</h1>
            <p className="text-muted-foreground">
              Wir haben Ihnen eine E-Mail mit einem Link zum Zurücksetzen Ihres Passworts gesendet. Bitte überprüfen Sie
              Ihren Posteingang und folgen Sie den Anweisungen.
            </p>
          </div>
          <Button asChild className="w-full">
            <Link href="/auth/login">Zurück zur Anmeldung</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container flex h-screen w-screen flex-col items-center justify-center">
      <div className="w-full max-w-md space-y-6">
        <div className="space-y-2 text-center">
          <h1 className="text-2xl font-bold tracking-tight">Passwort zurücksetzen</h1>
          <p className="text-muted-foreground">Geben Sie Ihre E-Mail-Adresse ein, um Ihr Passwort zurückzusetzen.</p>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">E-Mail</Label>
            <Input
              id="email"
              type="email"
              placeholder="max@beispiel.de"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Link zum Zurücksetzen senden"}
          </Button>
        </form>

        <p className="text-center text-sm text-muted-foreground">
          <Link href="/auth/login" className="text-primary hover:underline">
            Zurück zur Anmeldung
          </Link>
        </p>
      </div>
    </div>
  )
}

