"use client"

import { useEffect } from "react"
import type { Metadata } from "next"
import { RuleSection } from "@/components/RuleSection"
import { useSidebar } from "@/components/SidebarProvider"

export const metadata: Metadata = {
  title: "Regelwerk | Magic Towers League",
  description: "Offizielles Regelwerk der Magic Towers League",
}

export default function Regelwerk() {
  const { isOpen } = useSidebar()

  const rules = [
    {
      title: "1. Teamzusammensetzung",
      items: [
        "Jedes Team besteht aus mindestens vier Spielern.",
        "Spieler dürfen pro Saison nur für ein Team antreten.",
        "Gespielt wird 2 gegen 2 an einem Magic Towers League-Spieltisch.",
        "Ersatzspieler sind erlaubt, um einen reibungslosen Ligabetrieb zu gewährleisten.",
      ],
    },
    {
      title: "2. Spieltag & Ablauf",
      items: [
        "Ein Spieltag dauert ca. 110 Minuten.",
        "Gespielt werden zweimal 5 Spiele mit einer 15-minütigen Pause.",
        "Nach den ersten 5 Spielen werden die Sitzplätze gegen den Uhrzeigersinn getauscht.",
        "Vor dem Seitenwechsel wird das Display gereinigt, um optimale Bedingungen zu sichern.",
        "Nach Spielende dürfen die Spieler nicht aufstehen oder das Display berühren (Hände hinter den Rücken), um Touchscreen-Fehler zu vermeiden.",
      ],
    },
    {
      title: "3. Ergebniserfassung",
      items: [
        "Die Ergebnisse werden über die MTL-App oder die Liga-Homepage eingetragen.",
        "Zur Sicherstellung der Richtigkeit erfolgt die Eingabe mit einer Zwei-Faktor-Authentifizierung durch die Verantwortlichen beider Teams.",
        "Bei Uneinigkeit erhält kein Team Punkte, bis eine eindeutige Klärung erfolgt.",
      ],
    },
    {
      title: "4. Punktevergabe pro Spiel",
      items: [
        "Bester Spieler: 3 Teampunkte",
        "Zweitbester Spieler: 2 Teampunkte",
        "Drittbester Spieler: 1 Teampunkt",
        "Viertbester Spieler: 0 Punkte",
        "Pro Spieltag gibt es insgesamt 60 Teampunkte zu gewinnen.",
        "Ein Team kann maximal 50 oder mindestens 10 Teampunkte erreichen.",
        "Nach 10 Spielen sind Unentschieden (30:30) möglich.",
      ],
    },
    {
      title: "5. Ligawertung & Tabelle",
      items: [
        "Das Team mit den meisten Punkten nach 10 Spielen erhält 2 Punkte für die Tabelle.",
        "Bei einem Unentschieden erhalten beide Teams 1 Punkt.",
        "Das unterlegene Team erhält 0 Punkte.",
        "Falls nach Saisonende mehrere Teams punktgleich sind, entscheidet der direkte Vergleich über die Platzierung.",
      ],
    },
  ]

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "auto"
    return () => {
      document.body.style.overflow = "auto"
    }
  }, [isOpen])

  return (
    <div
      className={`min-h-screen bg-gradient-to-b from-indigo-950 via-blue-900 to-indigo-950 text-white transition-all duration-300 ${isOpen ? "pl-64" : "pl-0"}`}
    >
      <div className="container mx-auto px-4 py-16 max-w-6xl">
        <h1 className="text-4xl font-bold mb-8 text-center bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          Magic Towers League – Offizielles Regelwerk
        </h1>

        <div className="mb-8 bg-indigo-900/30 backdrop-blur-sm rounded-lg p-6 shadow-lg">
          <h2 className="text-2xl font-semibold mb-4 text-blue-300">Willkommen im Regelwerk</h2>
          <p className="text-blue-100">
            Hier findest du die offiziellen Regeln und Richtlinien für die Magic Towers League. Diese Regeln sind darauf
            ausgelegt, einen reibungslosen und fairen Spielbetrieb zu gewährleisten. Bitte lies die Regeln sorgfältig
            durch und halte dich daran. Bei Fragen oder Unklarheiten wende dich bitte an die Liga-Administratoren.
          </p>
        </div>

        <div className="space-y-6">
          {rules.map((rule, index) => (
            <RuleSection key={index} title={rule.title} items={rule.items} />
          ))}
        </div>
      </div>
    </div>
  )
}

