import { NextResponse } from "next/server"
import { getFirebaseAuth } from "@/lib/firebase"
import { getFirestore, collection, addDoc } from "firebase/firestore"

export async function POST(request: Request) {
  const auth = getFirebaseAuth()
  const user = auth.currentUser

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { teamName, playerName, email, phone } = await request.json()

    const db = getFirestore()
    const teamsCollection = collection(db, "teams")

    await addDoc(teamsCollection, {
      teamName,
      playerName,
      email,
      phone,
      userId: user.uid,
      createdAt: new Date().toISOString(),
    })

    return NextResponse.json({ message: "Team created successfully" }, { status: 201 })
  } catch (error) {
    console.error("Error creating team:", error)
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 })
  }
}

